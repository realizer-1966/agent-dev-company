var N=!0,x=null;async function k(t,s="https://yadonghaja-sync.dydtnsp.workers.dev"){x={posts:[],feed_items:[],cheers:[],user_profiles:[],applications:[],verifications:[],missions:[],badges:[],streaks:[],point_ledger:[],rankings:[]};try{let e=new Worker(new URL("./worker.js",import.meta.url),{type:"module"}),a=null,i=0,b=new Map;return await new Promise((r,l)=>{let d=setTimeout(()=>l(new Error("Syncular timeout")),5e3);e.onmessage=u=>{let{type:p,id:v,rows:L,state:tt}=u.data;p==="worker-ready"&&(a={worker:e,pending:b,nextId:()=>`m_${++i}`},clearTimeout(d),r())},e.postMessage({type:"worker-init",config:{actorId:t,baseUrl:s}})}),console.log("[sync] Syncular \uC5F0\uACB0\uB428"),N=!1,{async mutate(r,l){let d=a.nextId();return new Promise((u,p)=>{a.pending.set(d,u),a.worker.postMessage({type:"mutate",id:d,config:{table:r,row:l}}),setTimeout(()=>{a.pending.delete(d),p(new Error("timeout"))},5e3)})},async query(r,l=[]){let d=a.nextId();return new Promise((u,p)=>{a.pending.set(d,u),a.worker.postMessage({type:"query",id:d,config:{sql:r,params:l}}),setTimeout(()=>{a.pending.delete(d),p(new Error("timeout"))},5e3)})},subscribe(r,l){a.worker.postMessage({type:"subscribe",config:{subscriptionId:r,spec:l}})},async getSyncState(){let r=a.nextId();return new Promise((l,d)=>{a.pending.set(r,l),a.worker.postMessage({type:"get-sync-state",id:r}),setTimeout(()=>{a.pending.delete(r),l({phase:"connected"})},5e3)})},onSyncStateChange(r){let l=setInterval(async()=>{try{r(await this.getSyncState())}catch{}},5e3);return()=>clearInterval(l)}}}catch(e){console.warn("[sync] Syncular \uC2E4\uD328 \u2014 \uC778\uBA54\uBAA8\uB9AC \uBAA8\uB4DC:",e.message)}return console.log("[sync] \uC778\uBA54\uBAA8\uB9AC \uC2A4\uD1A0\uC5B4 \uC0AC\uC6A9"),{async mutate(e,a){x[e]||(x[e]=[]);let i=x[e].findIndex(b=>b.id===a.id);i>=0?x[e][i]=a:x[e].push(a)},async query(e,a=[]){let i=e.match(/FROM\s+(\w+)(?:\s+WHERE\s+(.+))?/i);if(!i)return[];let b=i[1],r=i[2],l=x[b]||[];if(r){let d=r.match(/(\w+)\s*=\s*\?(\d+)/i);if(d){let u=d[1],p=parseInt(d[2])-1,v=a[p];l=l.filter(L=>L[u]===v)}}return l},subscribe(){},async getSyncState(){return{phase:"connected"}},onSyncStateChange(){return()=>{}}}}var c=null,o=null,m="home",$="\u{1F4AA}",n=t=>document.querySelector(t),y=n("#main"),T=n("#sheet"),I=n("#sheetMask"),U=n("#sheetTitle"),h=n("#sheetBody"),S=n("#toast"),E=n("#fab"),st=n("#connDot"),nt=n("#connLabel");function w(){return new Date().toISOString().slice(0,10)}function f(){return Date.now()}function g(t,s=2e3){S.textContent=t,S.classList.remove("hidden"),setTimeout(()=>S.classList.add("hidden"),s)}function C(t,s){U.textContent=t,h.innerHTML=s,I.style.display="block",T.classList.add("open")}function _(){T.classList.remove("open"),setTimeout(()=>{I.style.display="none",h.innerHTML=""},280)}async function A(){let t=localStorage.getItem("yadong_actor");t?(o=JSON.parse(t),c=await k(o.actorId),D()):W()}function W(){n("#onboard").style.display="flex";let t=["\u{1F4AA}","\u{1F3C3}","\u{1F6B4}","\u{1F9D8}","\u{1F3CB}\uFE0F","\u{1F94A}","\u26BD\uFE0F","\u{1F3C0}"],s=n("#obAvatars");s.innerHTML=t.map(e=>`<button class="avatar-chip chip bg-slate-800 border border-slate-600 text-2xl ${e===$?"ring-2 ring-orange-400":""}" data-a="${e}">${e}</button>`).join(""),s.querySelectorAll(".avatar-chip").forEach(e=>{e.onclick=()=>{$=e.dataset.a,s.querySelectorAll(".avatar-chip").forEach(a=>a.classList.remove("ring-2","ring-orange-400")),e.classList.add("ring-2","ring-orange-400")}}),n("#obName").focus(),n("#obStart").onclick=async()=>{let e=n("#obName").value.trim();if(e.length<2){g("\uC774\uB984\uC744 2 \uC790 \uC774\uC0C1 \uC785\uB825\uD574\uC918\uC694");return}let a="u_"+crypto.randomUUID().replace(/-/g,"").slice(0,12);o={actorId:a,name:e,avatar:$},localStorage.setItem("yadong_actor",JSON.stringify(o)),n("#onboard").style.display="none",c=await k(a),await B(),D()}}async function B(){let{actorId:t,name:s,avatar:e}=o;await c.mutate("user_profiles",{id:t,public_id:"main",display_name:s,avatar:e,interests:'["\uD648\uD2B8"]',created_at_ms:f(),updated_at_ms:f()}),await c.mutate("streaks",{id:t,user_id:t,current:0,best:0,last_date:null,updated_at_ms:f()}),await c.mutate("missions",{id:`${t}:${w()}:0`,user_id:t,kind:"daily",date:w(),title:"\uCCAB \uC6B4\uB3D9 \uC778\uC99D!",goal:1,status:"pending",updated_at_ms:f()})}async function M(){let t=await c.query("SELECT balance_after FROM point_ledger WHERE user_id = ?1 ORDER BY created_at_ms DESC LIMIT 1",[o.actorId]);return t.length>0?t[0].balance_after:0}async function R(){return(await c.query("SELECT * FROM streaks WHERE user_id = ?1",[o.actorId]))[0]||null}async function J(){let t=await c.query("SELECT user_id, total_points, RANK() OVER (ORDER BY total_points DESC) as rank FROM rankings WHERE group_id = ?1",["main"]);return t.find(e=>e.user_id===o.actorId)?.rank||t.length+1}async function D(){await Y(),await O(m),K(),E.style.display=m==="recruit"||m==="mission"?"block":"none",E.onclick=()=>{m==="recruit"?q():m==="mission"&&j()}}async function Y(){let t=await M(),s=await R();n("#headerPoints").textContent=t+" P",n("#headerStreak").textContent=`\u{1F525} ${s?.current||0}\uC77C`}function K(){document.querySelectorAll(".tabbtn").forEach(t=>{t.onclick=async()=>{m=t.dataset.tab,await O(m),E.style.display=m==="recruit"||m==="mission"?"block":"none"}})}async function O(t){t==="home"?await G():t==="recruit"?await P():t==="mission"?await F():t==="feed"?await z():t==="profile"?await X():t==="rank"&&await Z()}async function G(){let t=await c.query("SELECT * FROM posts WHERE public_id = 'main' ORDER BY created_at_ms DESC LIMIT 10"),s=await R(),e=await M();y.innerHTML=`
    <div class="fade-in">
      <div class="bg-gradient-to-br from-orange-500/20 to-rose-500/20 border border-orange-500/30 rounded-3xl p-5 mb-4">
        <div class="text-sm text-slate-300 mb-1">\uC624\uB298\uC758 \uBBF8\uC158</div>
        <div class="text-lg font-black text-white mb-3">\uCCAB \uC6B4\uB3D9 \uC778\uC99D!</div>
        <button onclick="window.openMissionSheet()" class="btn bg-gradient-to-r from-orange-500 to-rose-500 text-white font-bold px-5 py-2.5 rounded-xl text-sm">\uC778\uC99D\uD558\uAE30</button>
      </div>
      <div class="grid grid-cols-2 gap-3 mb-4">
        <div class="bg-slate-800/80 border border-slate-700 rounded-2xl p-4">
          <div class="text-[10px] text-slate-400">\uC2A4\uD2B8\uB9AD</div>
          <div class="text-2xl font-black text-orange-300">${s?.current||0}\uC77C</div>
        </div>
        <div class="bg-slate-800/80 border border-slate-700 rounded-2xl p-4">
          <div class="text-[10px] text-slate-400">\uD3EC\uC778\uD2B8</div>
          <div class="text-2xl font-black text-amber-300">${e} P</div>
        </div>
      </div>
      <h3 class="text-lg font-extrabold mb-3 text-slate-200">\u{1F4CB} \uCD5C\uADFC \uBAA8\uC9D1\uAE00</h3>
      ${t.length?t.map(a=>H(a)).join(""):'<p class="text-slate-400 text-sm text-center py-8">\uC544\uC9C1 \uBAA8\uC9D1\uAE00\uC774 \uC5C6\uC5B4\uC694</p>'}
    </div>
  `}async function P(){let t=await c.query("SELECT * FROM posts WHERE public_id = 'main' ORDER BY created_at_ms DESC LIMIT 20");y.innerHTML=t.length?t.map(s=>H(s)).join(""):`
    <div class="text-center py-16">
      <div class="text-6xl mb-4">\u{1F44B}</div>
      <p class="text-slate-400 text-sm">\uC544\uC9C1 \uBAA8\uC9D1\uAE00\uC774 \uC5C6\uC5B4\uC694</p>
      <button onclick="window.openRecruitSheet()" class="btn mt-4 bg-gradient-to-r from-orange-500 to-rose-500 text-white font-bold px-6 py-3 rounded-2xl text-sm">\uCCAB \uBAA8\uC9D1\uAE00 \uC4F0\uAE30</button>
    </div>
  `}function H(t){let s=JSON.parse(t.types||"[]");return`
    <div class="card bg-slate-800/80 border border-slate-700 rounded-2xl p-4 mb-3">
      <div class="flex items-center gap-2 mb-2">
        <span class="text-xl">${t.author_avatar}</span>
        <span class="font-bold text-slate-200 text-sm">${t.author_name}</span>
        <span class="text-[10px] text-slate-500 ml-auto">${new Date(t.created_at_ms).toLocaleDateString()}</span>
      </div>
      <div class="flex flex-wrap gap-1.5 mb-2">
        ${s.map(e=>`<span class="chip bg-slate-900 border border-slate-600 text-[10px]">${e}</span>`).join("")}
      </div>
      <div class="text-sm text-slate-300 mb-2">${t.mode} \xB7 ${t.region} \xB7 ${t.time_slot}</div>
      <div class="text-slate-400 text-sm mb-3 line-clamp-2">${t.intro}</div>
      <div class="flex items-center gap-2">
        <span class="text-[10px] text-slate-500">\uC815\uC6D0 ${t.capacity}\uBA85</span>
        <span class="text-[10px] text-slate-500">\uB9C8\uAC10 ${t.deadline}</span>
      </div>
      <button onclick="openApply('${t.id}')" class="btn w-full mt-3 bg-slate-700 hover:bg-slate-600 text-white font-bold py-2.5 rounded-xl text-sm">\uC2E0\uCCAD\uD558\uAE30</button>
    </div>
  `}async function F(){let t=await c.query("SELECT * FROM missions WHERE user_id = ?1 ORDER BY date DESC LIMIT 10",[o.actorId]);y.innerHTML=t.length?t.map(s=>V(s)).join(""):`
    <div class="text-center py-16">
      <div class="text-6xl mb-4">\u2705</div>
      <p class="text-slate-400 text-sm">\uBBF8\uC158\uC774 \uC5C6\uC5B4\uC694</p>
    </div>
  `}function V(t){let s=t.status==="done";return`
    <div class="card bg-slate-800/80 border border-slate-700 rounded-2xl p-4 mb-3 ${s?"opacity-60":""}">
      <div class="flex items-center gap-3 mb-2">
        <span class="text-2xl">${s?"\u2705":"\u23F3"}</span>
        <div class="flex-1">
          <div class="font-bold text-slate-200">${t.title}</div>
          <div class="text-xs text-slate-400">${t.date}</div>
        </div>
      </div>
      ${s?'<div class="text-sm text-emerald-400 font-bold">\uC778\uC99D \uC644\uB8CC!</div>':`<button onclick="verifyMission('${t.id}', '${t.title}')" class="btn w-full bg-gradient-to-r from-orange-500 to-rose-500 text-white font-bold py-2.5 rounded-xl text-sm">\uC778\uC99D\uD558\uAE30</button>`}
    </div>
  `}async function z(){let t=await c.query("SELECT * FROM feed_items ORDER BY created_at_ms DESC LIMIT 30");y.innerHTML=t.length?t.map(s=>Q(s)).join(""):'<p class="text-slate-400 text-sm mt-8 text-center">\uC544\uC9C1 \uD53C\uB4DC\uAC00 \uC5C6\uC5B4\uC694</p>'}function Q(t){return`
    <div class="card bg-slate-800/80 border border-slate-700 rounded-2xl p-4 mb-3">
      <div class="flex items-center gap-2 mb-2">
        <span class="text-xl">${t.avatar}</span>
        <span class="font-bold text-slate-200 text-sm">${t.user_name}</span>
        <span class="text-[10px] text-slate-500 ml-auto">${new Date(t.created_at_ms).toLocaleDateString()}</span>
      </div>
      <div class="font-extrabold text-slate-100 mb-1">${t.mission_title}</div>
      ${t.memo?`<p class="text-sm text-slate-300 mb-2">${t.memo}</p>`:""}
      ${t.photo?`<img src="${t.photo}" class="w-full rounded-xl mb-2 border border-slate-600" />`:""}
      <div class="flex items-center gap-2 mt-2">
        <button class="cheer-btn text-lg" onclick="sendCheer('${t.id}', 'fire')">\u{1F525}</button>
        <button class="cheer-btn text-lg" onclick="sendCheer('${t.id}', 'thumb')">\u{1F44D}</button>
        <button class="cheer-btn text-lg" onclick="sendCheer('${t.id}', 'muscle')">\u{1F4AA}</button>
      </div>
    </div>
  `}async function X(){let t=await c.query("SELECT * FROM badges WHERE user_id = ?1",[o.actorId]),s=await R(),e=await M(),a=await J();y.innerHTML=`
    <div class="fade-in text-center">
      <div class="text-6xl mb-2">${o.avatar}</div>
      <h2 class="text-xl font-extrabold">${o.name}</h2>
      <div class="text-sm text-slate-400 mt-1">${o.actorId.slice(0,12)}</div>
      <div class="flex justify-center gap-4 mt-4">
        <div class="bg-slate-800/80 border border-slate-700 rounded-2xl px-4 py-3">
          <div class="text-[10px] text-slate-400">\uD3EC\uC778\uD2B8</div>
          <div class="text-lg font-black text-amber-300">${e} P</div>
        </div>
        <div class="bg-slate-800/80 border border-slate-700 rounded-2xl px-4 py-3">
          <div class="text-[10px] text-slate-400">\uC2A4\uD2B8\uB9AD</div>
          <div class="text-lg font-black text-orange-300">${s?.current||0}\uC77C</div>
        </div>
        <div class="bg-slate-800/80 border border-slate-700 rounded-2xl px-4 py-3">
          <div class="text-[10px] text-slate-400">\uB7AD\uD0B9</div>
          <div class="text-lg font-black text-emerald-300">${a}\uC704</div>
        </div>
      </div>
      <h3 class="text-lg font-extrabold mt-6 mb-3 text-slate-200">\u{1F3C6} \uBC30\uC9C0</h3>
      ${t.length?`<div class="flex flex-wrap justify-center gap-2">${t.map(i=>`<span class="chip bg-slate-800 border border-slate-600">${i.badge_name}</span>`).join("")}</div>`:'<p class="text-slate-400 text-sm">\uC544\uC9C1 \uD68D\uB4DD\uD55C \uBC30\uC9C0\uAC00 \uC5C6\uC5B4\uC694</p>'}
    </div>
  `}async function Z(){let t=await c.query("SELECT r.*, u.display_name, u.avatar FROM rankings r JOIN user_profiles u ON r.user_id = u.id WHERE r.group_id = 'main' ORDER BY r.total_points DESC LIMIT 20");y.innerHTML=`
    <div class="fade-in">
      <h3 class="text-lg font-extrabold mb-4 text-slate-200">\u{1F3C5} \uC804\uCCB4 \uB7AD\uD0B9</h3>
      ${t.map((s,e)=>`
        <div class="card bg-slate-800/80 border border-slate-700 rounded-2xl p-4 mb-3 flex items-center gap-3">
          <span class="text-2xl font-black ${e<3?"text-amber-400":"text-slate-500"}">${e+1}</span>
          <span class="text-xl">${s.avatar}</span>
          <span class="font-bold text-slate-200 flex-1">${s.display_name}</span>
          <span class="text-amber-300 font-black">${s.total_points} P</span>
        </div>
      `).join("")}
    </div>
  `}async function q(){C("\uBA54\uC774\uD2B8 \uBAA8\uC9D1\uAE00 \uC4F0\uAE30",`
    <form id="recruitForm" class="space-y-3">
      <div><label class="block text-xs font-bold text-slate-400 mb-1">\uC6B4\uB3D9 \uC885\uB958 (\uCD5C\uB300 3 \uAC1C)</label>
        <div class="flex flex-wrap gap-2" id="typeChips">${["\uB7EC\uB2DD","\uAC77\uAE30","\uD5EC\uC2A4","\uD648\uD2B8","\uC790\uC804\uAC70","\uC694\uAC00","\uC218\uC601","\uB4F1\uC0B0"].map(e=>`<button type="button" class="chip bg-slate-900 border border-slate-600 type-chip">${e}</button>`).join("")}</div>
        <input type="hidden" id="types" value="[]"></div>
      <div><label class="block text-xs font-bold text-slate-400 mb-1">\uBC29\uC2DD</label><select id="mode" class="w-full bg-slate-900 border border-slate-600 rounded-xl px-3 py-2.5 text-white font-bold"><option>\uC628\uB77C\uC778</option><option>\uC624\uD504\uB77C\uC778</option></select></div>
      <div><label class="block text-xs font-bold text-slate-400 mb-1">\uC9C0\uC5ED</label><input id="region" class="w-full bg-slate-900 border border-slate-600 rounded-xl px-3 py-2.5 text-white font-bold" placeholder="\uC608: \uC11C\uC6B8 \uAC15\uB0A8\uAD6C"></div>
      <div><label class="block text-xs font-bold text-slate-400 mb-1">\uC694\uC77C</label><div class="flex justify-between" id="dayChips">${["\uC77C","\uC6D4","\uD654","\uC218","\uBAA9","\uAE08","\uD1A0"].map((e,a)=>`<button type="button" class="chip bg-slate-900 border border-slate-600 day-chip" data-i="${a}">${e}</button>`).join("")}</div><input type="hidden" id="days" value="[]"></div>
      <div><label class="block text-xs font-bold text-slate-400 mb-1">\uC2DC\uAC04\uB300</label><input id="timeSlot" class="w-full bg-slate-900 border border-slate-600 rounded-xl px-3 py-2.5 text-white font-bold" placeholder="\uC608: \uC544\uCE68 7 \uC2DC"></div>
      <div><label class="block text-xs font-bold text-slate-400 mb-1">\uC815\uC6D0</label><input id="capacity" type="number" min="1" max="6" value="3" class="w-full bg-slate-900 border border-slate-600 rounded-xl px-3 py-2.5 text-white font-bold"></div>
      <div><label class="block text-xs font-bold text-slate-400 mb-1">\uD55C\uB9C8\uB514</label><textarea id="intro" rows="3" class="w-full bg-slate-900 border border-slate-600 rounded-xl px-3 py-2.5 text-white font-bold" placeholder="\uC5B4\uB5A4 \uBA54\uC774\uD2B8\uB97C \uCC3E\uB098\uC694?"></textarea></div>
      <div><label class="block text-xs font-bold text-slate-400 mb-1">\uB9C8\uAC10\uC77C</label><input id="deadline" type="date" value="${w()}" class="w-full bg-slate-900 border border-slate-600 rounded-xl px-3 py-2.5 text-white font-bold"></div>
      <button type="submit" class="btn w-full bg-gradient-to-r from-orange-500 to-rose-500 text-white font-extrabold py-3.5 rounded-2xl">\uC62C\uB9AC\uAE30</button>
    </form>
  `);let t=[],s=[];h.querySelectorAll(".type-chip").forEach(e=>{e.onclick=()=>{let a=e.textContent,i=t.indexOf(a);if(i>=0)t.splice(i,1),e.classList.remove("bg-orange-500","text-white"),e.classList.add("bg-slate-900");else{if(t.length>=3)return g("\uCD5C\uB300 3 \uAC1C");t.push(a),e.classList.remove("bg-slate-900"),e.classList.add("bg-orange-500","text-white")}n("#types").value=JSON.stringify(t)}}),h.querySelectorAll(".day-chip").forEach(e=>{e.onclick=()=>{let a=+e.dataset.i,i=s.indexOf(a);i>=0?(s.splice(i,1),e.classList.remove("bg-amber-500","text-white"),e.classList.add("bg-slate-900")):(s.push(a),e.classList.remove("bg-slate-900"),e.classList.add("bg-amber-500","text-white")),n("#days").value=JSON.stringify(s)}}),n("#recruitForm").onsubmit=async e=>{e.preventDefault();let a=JSON.parse(n("#types").value),i=JSON.parse(n("#days").value);if(!a.length)return g("\uC6B4\uB3D9 \uC885\uB958\uB97C \uC120\uD0DD\uD574\uC918\uC694");if(!i.length)return g("\uC694\uC77C\uC744 \uC120\uD0DD\uD574\uC918\uC694");let b=n("#region").value.trim(),r=n("#timeSlot").value.trim(),l=parseInt(n("#capacity").value),d=n("#intro").value.trim(),u=n("#deadline").value,p=n("#mode").value,v="post_"+crypto.randomUUID().slice(0,8);await c.mutate("posts",{id:v,public_id:"main",author_id:o.actorId,author_name:o.name,author_avatar:o.avatar,types:JSON.stringify(a),mode:p,region:b,days:JSON.stringify(i),time_slot:r,capacity:l,intro:d,deadline:u,created_at_ms:f()}),await c.mutate("feed_items",{id:"feed_"+v,public_id:"main",user_id:o.actorId,user_name:o.name,avatar:o.avatar,mission_title:`\uBA54\uC774\uD2B8 \uBAA8\uC9D1: ${a.join(", ")}`,memo:d,photo:null,created_at_ms:f()}),_(),g("\uBAA8\uC9D1\uAE00 \uB4F1\uB85D \uC644\uB8CC!"),await P()}}async function j(){C("\uBBF8\uC158 \uCD94\uAC00",`
    <form id="missionForm" class="space-y-3">
      <input id="mTitle" class="w-full bg-slate-900 border border-slate-600 rounded-xl px-3 py-2.5 text-white font-bold" placeholder="\uBBF8\uC158 \uC81C\uBAA9">
      <input id="mGoal" type="number" min="1" value="1" class="w-full bg-slate-900 border border-slate-600 rounded-xl px-3 py-2.5 text-white font-bold" placeholder="\uBAA9\uD45C \uD69F\uC218">
      <select id="mKind" class="w-full bg-slate-900 border border-slate-600 rounded-xl px-3 py-2.5 text-white font-bold"><option value="daily">\uC77C\uC77C \uBBF8\uC158</option><option value="weekly">\uC8FC\uAC04 \uBBF8\uC158</option></select>
      <button type="submit" class="btn w-full bg-gradient-to-r from-orange-500 to-rose-500 text-white font-extrabold py-3.5 rounded-2xl">\uCD94\uAC00</button>
    </form>
  `),n("#missionForm").onsubmit=async t=>{t.preventDefault();let s=n("#mTitle").value.trim(),e=parseInt(n("#mGoal").value),a=n("#mKind").value;if(!s)return g("\uC81C\uBAA9\uC744 \uC785\uB825\uD574\uC918\uC694");await c.mutate("missions",{id:`${o.actorId}:${w()}:${a}`,user_id:o.actorId,kind:a,date:w(),title:s,goal:e,status:"pending",updated_at_ms:f()}),_(),g("\uBBF8\uC158 \uCD94\uAC00 \uC644\uB8CC!"),await F()}}n("#sheetClose").onclick=_;I.onclick=_;window.openRecruitSheet=q;window.openMissionSheet=j;A();
