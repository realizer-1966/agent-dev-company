var v={posts:[],feed_items:[],cheers:[],user_profiles:[],applications:[],group_members:[],verifications:[],missions:[],point_ledger:[],streaks:[],badges:[]};function k(e){return console.log("[inmem] adapter created for",e),{subscribe(s,{table:t,scopes:o}){console.log("[inmem] subscribe:",s,t)},onSyncStateChange(s){s({phase:"connected"})},query(s,t=[]){let o=s.match(/FROM\s+(\w+)/i);if(!o)return[];let l=o[1],d=v[l]||[];return t.length>0&&s.includes("user_id = ?1")?d.filter(p=>p.user_id===t[0]):t.length>0&&s.includes("id = ?1")?d.filter(p=>p.id===t[0]):d},async mutate(s,t){let o=v[s]||(v[s]=[]),l=o.findIndex(d=>d.id===t.id);l>=0?o[l]={...o[l],...t}:o.push(t),console.log("[inmem] mutate:",s,t.id)},async syncUntilIdle(){console.log("[inmem] syncUntilIdle")},handle:{async syncUntilIdle(){console.log("[inmem] handle.syncUntilIdle")}}}}var n=null,i=null,r="home",y="\u{1F4AA}",a=e=>document.querySelector(e),m=a("#main"),I=a("#sheet"),_=a("#sheetMask"),A=a("#sheetTitle"),x=a("#sheetBody"),g=a("#toast"),h=a("#fab"),N=a("#connDot"),P=a("#connLabel");function b(){return new Date().toISOString().slice(0,10)}function c(){return Date.now()}function u(e,s=2e3){g.textContent=e,g.classList.remove("hidden"),setTimeout(()=>g.classList.add("hidden"),s)}function L(e,s){A.textContent=e,x.innerHTML=s,_.style.display="block",I.classList.add("open")}function f(){I.classList.remove("open"),setTimeout(()=>{_.style.display="none",x.innerHTML=""},280)}async function J(){let e=localStorage.getItem("yadong_actor");e?(i=JSON.parse(e),await M(i.actorId),T()):B()}function B(){a("#onboard").style.display="flex";let e=["\u{1F4AA}","\u{1F3C3}","\u{1F6B4}","\u{1F9D8}","\u{1F3CB}\uFE0F","\u{1F94A}","\u26BD\uFE0F","\u{1F3C0}"],s=a("#obAvatars");s.innerHTML=e.map(t=>`<button class="avatar-chip chip bg-slate-800 border border-slate-600 text-2xl ${t===y?"ring-2 ring-orange-400":""}" data-a="${t}">${t}</button>`).join(""),s.querySelectorAll(".avatar-chip").forEach(t=>{t.onclick=()=>{y=t.dataset.a,s.querySelectorAll(".avatar-chip").forEach(o=>o.classList.remove("ring-2","ring-orange-400")),t.classList.add("ring-2","ring-orange-400")}}),a("#obName").focus(),a("#obStart").onclick=async()=>{let t=a("#obName").value.trim();if(t.length<2){u("\uC774\uB984\uC744 2 \uC790 \uC774\uC0C1 \uC785\uB825\uD574\uC918\uC694");return}let o="u_"+crypto.randomUUID().replace(/-/g,"").slice(0,12);i={actorId:o,name:t,avatar:y},localStorage.setItem("yadong_actor",JSON.stringify(i)),a("#onboard").style.display="none",await M(o),await W(),T()}}async function M(e){console.log("[app] startSync for",e),n=k(e),n.subscribe("publicPosts",{table:"posts",scopes:{public_id:["main"]}}),n.subscribe("publicFeed",{table:"feed_items",scopes:{public_id:["main"]}}),n.subscribe("publicCheers",{table:"cheers",scopes:{public_id:["main"]}}),n.subscribe("allApplies",{table:"applications",scopes:{apply_scope:["open"]}}),n.subscribe("allVerifs",{table:"verifications",scopes:{verify_scope:["live"]}}),n.subscribe("myMissions",{table:"missions",scopes:{user_id:[e]}}),n.subscribe("myLedger",{table:"point_ledger",scopes:{user_id:[e]}}),n.subscribe("myStreak",{table:"streaks",scopes:{user_id:[e]}}),n.subscribe("myBadges",{table:"badges",scopes:{user_id:[e]}}),n.onSyncStateChange(s=>{let t=s?.phase||"connected";N.className=`w-2 h-2 rounded-full ${t==="connected"?"bg-emerald-400":"bg-slate-500"}`,P.textContent=t==="connected"?"\uC2E4\uC2DC\uAC04 \uB3D9\uAE30\uD654":"\uC624\uD504\uB77C\uC778"}),console.log("[app] sync initialized")}async function W(){let{actorId:e,name:s,avatar:t}=i;await n.mutate("user_profiles",{id:e,public_id:"main",display_name:s,avatar:t,interests:'["\uD648\uD2B8"]',created_at_ms:c(),updated_at_ms:c()}),await n.mutate("streaks",{id:e,user_id:e,current:0,best:0,last_date:null,updated_at_ms:c()}),await n.mutate("missions",{id:`${e}:${b()}:0`,user_id:e,kind:"daily",date:b(),title:"\uCCAB \uC6B4\uB3D9 \uC778\uC99D!",goal:1,status:"pending",updated_at_ms:c()})}function T(){Y(),C(r),G(),h.style.display=r==="recruit"||r==="mission"?"block":"none",h.onclick=()=>{r==="recruit"?F():r==="mission"&&H()}}function Y(){a("#headerPoints").textContent=w()+" P";let e=$();a("#headerStreak").textContent=`\u{1F525} ${e?.current||0}\uC77C`}function w(){let e=n.query("SELECT balance_after FROM point_ledger WHERE user_id = ?1 ORDER BY created_at_ms DESC LIMIT 1",[i.actorId]);return e.length>0?e[0].balance_after:0}function $(){return n.query("SELECT * FROM streaks WHERE user_id = ?1",[i.actorId])[0]||null}function G(){document.querySelectorAll(".tabbtn").forEach(e=>{e.onclick=()=>{r=e.dataset.tab,C(r),h.style.display=r==="recruit"||r==="mission"?"block":"none"}})}function C(e){e==="home"?K():e==="recruit"?D():e==="mission"?O():e==="feed"?V():e==="profile"&&X()}function K(){let e=n.query("SELECT * FROM posts WHERE public_id = 'main' ORDER BY created_at_ms DESC LIMIT 10"),s=$(),t=w();m.innerHTML=`
    <div class="fade-in">
      <div class="bg-gradient-to-br from-orange-500/20 to-rose-500/20 border border-orange-500/30 rounded-3xl p-5 mb-4">
        <div class="text-sm text-slate-300 mb-1">\uC624\uB298\uC758 \uBBF8\uC158</div>
        <div class="text-lg font-black text-white mb-3">\uCCAB \uC6B4\uB3D9 \uC778\uC99D!</div>
        <button onclick="window.openMissionSheet()" class="btn bg-gradient-to-r from-orange-500 to-rose-500 text-white font-bold px-5 py-2.5 rounded-xl text-sm">\uC778\uC99D\uD558\uAE30</button>
      </div>
      <div class="grid grid-cols-2 gap-3 mb-4">
        <div class="bg-slate-800/80 border border-slate-700 rounded-2xl p-4">
          <div class="text-[10px] text-slate-400">\uC2A4\uD2B8\uB9AD</div>
          <div class="text-2xl font-black text-orange-300">${s?.current||0}\uC77C</div>
        </div>
        <div class="bg-slate-800/80 border border-slate-700 rounded-2xl p-4">
          <div class="text-[10px] text-slate-400">\uD3EC\uC778\uD2B8</div>
          <div class="text-2xl font-black text-amber-300">${t} P</div>
        </div>
      </div>
      <h3 class="text-lg font-extrabold mb-3 text-slate-200">\u{1F4CB} \uCD5C\uADFC \uBAA8\uC9D1\uAE00</h3>
      ${e.length?e.map(o=>R(o)).join(""):'<p class="text-slate-400 text-sm text-center py-8">\uC544\uC9C1 \uBAA8\uC9D1\uAE00\uC774 \uC5C6\uC5B4\uC694</p>'}
    </div>
  `}function D(){let e=n.query("SELECT * FROM posts WHERE public_id = 'main' ORDER BY created_at_ms DESC LIMIT 20");m.innerHTML=e.length?e.map(s=>R(s)).join(""):`
    <div class="text-center py-16">
      <div class="text-6xl mb-4">\u{1F44B}</div>
      <p class="text-slate-400 text-sm">\uC544\uC9C1 \uBAA8\uC9D1\uAE00\uC774 \uC5C6\uC5B4\uC694</p>
      <button onclick="window.openRecruitSheet()" class="btn mt-4 bg-gradient-to-r from-orange-500 to-rose-500 text-white font-bold px-6 py-3 rounded-2xl text-sm">\uCCAB \uBAA8\uC9D1\uAE00 \uC4F0\uAE30</button>
    </div>
  `}function R(e){let s=JSON.parse(e.types||"[]");return`
    <div class="card bg-slate-800/80 border border-slate-700 rounded-2xl p-4 mb-3">
      <div class="flex items-center gap-2 mb-2">
        <span class="text-xl">${e.author_avatar}</span>
        <span class="font-bold text-slate-200 text-sm">${e.author_name}</span>
        <span class="text-[10px] text-slate-500 ml-auto">${new Date(e.created_at_ms).toLocaleDateString()}</span>
      </div>
      <div class="flex flex-wrap gap-1.5 mb-2">
        ${s.map(t=>`<span class="chip bg-slate-900 border border-slate-600 text-[10px]">${t}</span>`).join("")}
      </div>
      <div class="text-sm text-slate-300 mb-2">${e.mode} \xB7 ${e.region} \xB7 ${e.time_slot}</div>
      <div class="text-slate-400 text-sm mb-3 line-clamp-2">${e.intro}</div>
      <div class="flex items-center gap-2">
        <span class="text-[10px] text-slate-500">\uC815\uC6D0 ${e.capacity}\uBA85</span>
        <span class="text-[10px] text-slate-500">\uB9C8\uAC10 ${e.deadline}</span>
      </div>
      <button onclick="openApply('${e.id}')" class="btn w-full mt-3 bg-slate-700 hover:bg-slate-600 text-white font-bold py-2.5 rounded-xl text-sm">\uC2E0\uCCAD\uD558\uAE30</button>
    </div>
  `}function O(){let e=n.query("SELECT * FROM missions WHERE user_id = ?1 ORDER BY date DESC LIMIT 10",[i.actorId]);m.innerHTML=e.length?e.map(s=>z(s)).join(""):`
    <div class="text-center py-16">
      <div class="text-6xl mb-4">\u2705</div>
      <p class="text-slate-400 text-sm">\uBBF8\uC158\uC774 \uC5C6\uC5B4\uC694</p>
    </div>
  `}function z(e){let s=e.status==="done";return`
    <div class="card bg-slate-800/80 border border-slate-700 rounded-2xl p-4 mb-3 ${s?"opacity-60":""}">
      <div class="flex items-center gap-3 mb-2">
        <span class="text-2xl">${s?"\u2705":"\u23F3"}</span>
        <div class="flex-1">
          <div class="font-bold text-slate-200">${e.title}</div>
          <div class="text-xs text-slate-400">${e.date}</div>
        </div>
      </div>
      ${s?'<div class="text-sm text-emerald-400 font-bold">\uC778\uC99D \uC644\uB8CC!</div>':`<button onclick="verifyMission('${e.id}', '${e.title}')" class="btn w-full bg-gradient-to-r from-orange-500 to-rose-500 text-white font-bold py-2.5 rounded-xl text-sm">\uC778\uC99D\uD558\uAE30</button>`}
    </div>
  `}function V(){let e=n.query("SELECT * FROM feed_items ORDER BY created_at_ms DESC LIMIT 30");m.innerHTML=e.length?e.map(s=>Q(s)).join(""):'<p class="text-slate-400 text-sm mt-8 text-center">\uC544\uC9C1 \uD53C\uB4DC\uAC00 \uC5C6\uC5B4\uC694</p>'}function Q(e){return`
    <div class="card bg-slate-800/80 border border-slate-700 rounded-2xl p-4 mb-3">
      <div class="flex items-center gap-2 mb-2">
        <span class="text-xl">${e.avatar}</span>
        <span class="font-bold text-slate-200 text-sm">${e.user_name}</span>
        <span class="text-[10px] text-slate-500 ml-auto">${new Date(e.created_at_ms).toLocaleDateString()}</span>
      </div>
      <div class="font-extrabold text-slate-100 mb-1">${e.mission_title}</div>
      ${e.memo?`<p class="text-sm text-slate-300 mb-2">${e.memo}</p>`:""}
      ${e.photo?'<div class="text-xs text-emerald-400 font-bold mb-2">\uC0AC\uC9C4 \u2705</div>':""}
      <div class="flex items-center gap-2 mt-2">
        <button class="cheer-btn text-lg" onclick="sendCheer('${e.id}', 'fire')">\u{1F525}</button>
        <button class="cheer-btn text-lg" onclick="sendCheer('${e.id}', 'thumb')">\u{1F44D}</button>
        <button class="cheer-btn text-lg" onclick="sendCheer('${e.id}', 'muscle')">\u{1F4AA}</button>
      </div>
    </div>
  `}function X(){let e=n.query("SELECT * FROM badges WHERE user_id = ?1",[i.actorId]),s=$(),t=w();m.innerHTML=`
    <div class="fade-in text-center">
      <div class="text-6xl mb-2">${i.avatar}</div>
      <h2 class="text-xl font-extrabold">${i.name}</h2>
      <div class="text-sm text-slate-400 mt-1">${i.actorId.slice(0,12)}</div>
      <div class="flex justify-center gap-4 mt-4">
        <div class="bg-slate-800/80 border border-slate-700 rounded-2xl px-4 py-3">
          <div class="text-[10px] text-slate-400">\uD3EC\uC778\uD2B8</div>
          <div class="text-lg font-black text-amber-300">${t} P</div>
        </div>
        <div class="bg-slate-800/80 border border-slate-700 rounded-2xl px-4 py-3">
          <div class="text-[10px] text-slate-400">\uC2A4\uD2B8\uB9AD</div>
          <div class="text-lg font-black text-orange-300">${s?.current||0}\uC77C</div>
        </div>
      </div>
      <h3 class="text-lg font-extrabold mt-6 mb-3 text-slate-200">\u{1F3C6} \uBC30\uC9C0</h3>
      ${e.length?`<div class="flex flex-wrap justify-center gap-2">${e.map(o=>`<span class="chip bg-slate-800 border border-slate-600">${o.badge_id}</span>`).join("")}</div>`:'<p class="text-slate-400 text-sm">\uC544\uC9C1 \uD68D\uB4DD\uD55C \uBC30\uC9C0\uAC00 \uC5C6\uC5B4\uC694</p>'}
    </div>
  `}function F(){L("\uBA54\uC774\uD2B8 \uBAA8\uC9D1\uAE00 \uC4F0\uAE30",`
    <form id="recruitForm" class="space-y-3">
      <div>
        <label class="block text-xs font-bold text-slate-400 mb-1">\uC6B4\uB3D9 \uC885\uB958 (\uCD5C\uB300 3 \uAC1C)</label>
        <div class="flex flex-wrap gap-2" id="typeChips">
          ${["\uB7EC\uB2DD","\uAC77\uAE30","\uD5EC\uC2A4","\uD648\uD2B8","\uC790\uC804\uAC70","\uC694\uAC00","\uC218\uC601","\uB4F1\uC0B0"].map(t=>`<button type="button" class="chip bg-slate-900 border border-slate-600 type-chip">${t}</button>`).join("")}
        </div>
        <input type="hidden" id="types" name="types" value="[]">
      </div>
      <div>
        <label class="block text-xs font-bold text-slate-400 mb-1">\uBC29\uC2DD</label>
        <select id="mode" class="w-full bg-slate-900 border border-slate-600 rounded-xl px-3 py-2.5 text-white font-bold">
          <option>\uC628\uB77C\uC778</option><option>\uC624\uD504\uB77C\uC778</option>
        </select>
      </div>
      <div>
        <label class="block text-xs font-bold text-slate-400 mb-1">\uC9C0\uC5ED</label>
        <input id="region" class="w-full bg-slate-900 border border-slate-600 rounded-xl px-3 py-2.5 text-white font-bold" placeholder="\uC608: \uC11C\uC6B8 \uAC15\uB0A8\uAD6C">
      </div>
      <div>
        <label class="block text-xs font-bold text-slate-400 mb-1">\uC694\uC77C</label>
        <div class="flex justify-between" id="dayChips">
          ${["\uC77C","\uC6D4","\uD654","\uC218","\uBAA9","\uAE08","\uD1A0"].map((t,o)=>`<button type="button" class="chip bg-slate-900 border border-slate-600 day-chip" data-i="${o}">${t}</button>`).join("")}
        </div>
        <input type="hidden" id="days" name="days" value="[]">
      </div>
      <div>
        <label class="block text-xs font-bold text-slate-400 mb-1">\uC2DC\uAC04\uB300</label>
        <input id="timeSlot" class="w-full bg-slate-900 border border-slate-600 rounded-xl px-3 py-2.5 text-white font-bold" placeholder="\uC608: \uC544\uCE68 7 \uC2DC">
      </div>
      <div>
        <label class="block text-xs font-bold text-slate-400 mb-1">\uC815\uC6D0</label>
        <input id="capacity" type="number" min="1" max="6" value="3" class="w-full bg-slate-900 border border-slate-600 rounded-xl px-3 py-2.5 text-white font-bold">
      </div>
      <div>
        <label class="block text-xs font-bold text-slate-400 mb-1">\uD55C\uB9C8\uB514</label>
        <textarea id="intro" rows="3" class="w-full bg-slate-900 border border-slate-600 rounded-xl px-3 py-2.5 text-white font-bold" placeholder="\uC5B4\uB5A4 \uBA54\uC774\uD2B8\uB97C \uCC3E\uB098\uC694?"></textarea>
      </div>
      <div>
        <label class="block text-xs font-bold text-slate-400 mb-1">\uB9C8\uAC10\uC77C</label>
        <input id="deadline" type="date" value="${b()}" class="w-full bg-slate-900 border border-slate-600 rounded-xl px-3 py-2.5 text-white font-bold">
      </div>
      <button type="submit" class="btn w-full bg-gradient-to-r from-orange-500 to-rose-500 text-white font-extrabold py-3.5 rounded-2xl">\uC62C\uB9AC\uAE30</button>
    </form>
  `);let e=[],s=[];x.querySelectorAll(".type-chip").forEach(t=>{t.onclick=()=>{let o=t.textContent,l=e.indexOf(o);if(l>=0)e.splice(l,1),t.classList.remove("bg-orange-500","text-white"),t.classList.add("bg-slate-900");else{if(e.length>=3)return u("\uCD5C\uB300 3 \uAC1C");e.push(o),t.classList.remove("bg-slate-900"),t.classList.add("bg-orange-500","text-white")}a("#types").value=JSON.stringify(e)}}),x.querySelectorAll(".day-chip").forEach(t=>{t.onclick=()=>{let o=+t.dataset.i,l=s.indexOf(o);l>=0?(s.splice(l,1),t.classList.remove("bg-amber-500","text-white"),t.classList.add("bg-slate-900")):(s.push(o),t.classList.remove("bg-slate-900"),t.classList.add("bg-amber-500","text-white")),a("#days").value=JSON.stringify(s)}}),a("#recruitForm").onsubmit=async t=>{t.preventDefault();let o=JSON.parse(a("#types").value),l=JSON.parse(a("#days").value);if(!o.length)return u("\uC6B4\uB3D9 \uC885\uB958\uB97C \uC120\uD0DD\uD574\uC918\uC694");if(!l.length)return u("\uC694\uC77C\uC744 \uC120\uD0DD\uD574\uC918\uC694");let d=a("#region").value.trim(),p=a("#timeSlot").value.trim(),U=parseInt(a("#capacity").value),S=a("#intro").value.trim(),j=a("#deadline").value,q=a("#mode").value,E=`post_${crypto.randomUUID().slice(0,8)}`;await n.mutate("posts",{id:E,public_id:"main",author_id:i.actorId,author_name:i.name,author_avatar:i.avatar,types:JSON.stringify(o),mode:q,region:d,days:JSON.stringify(l),time_slot:p,capacity:U,intro:S,deadline:j,created_at_ms:c()}),await n.mutate("feed_items",{id:`feed_${E}`,public_id:"main",user_id:i.actorId,user_name:i.name,avatar:i.avatar,mission_title:`\uBA54\uC774\uD2B8 \uBAA8\uC9D1: ${o.join(", ")}`,memo:S,photo:null,created_at_ms:c()}),f(),u("\uBAA8\uC9D1\uAE00 \uB4F1\uB85D \uC644\uB8CC!"),D()}}function H(){L("\uBBF8\uC158 \uCD94\uAC00",`
    <form id="missionForm" class="space-y-3">
      <input id="mTitle" class="w-full bg-slate-900 border border-slate-600 rounded-xl px-3 py-2.5 text-white font-bold" placeholder="\uBBF8\uC158 \uC81C\uBAA9">
      <input id="mGoal" type="number" min="1" value="1" class="w-full bg-slate-900 border border-slate-600 rounded-xl px-3 py-2.5 text-white font-bold" placeholder="\uBAA9\uD45C \uD69F\uC218">
      <select id="mKind" class="w-full bg-slate-900 border border-slate-600 rounded-xl px-3 py-2.5 text-white font-bold">
        <option value="daily">\uC77C\uC77C \uBBF8\uC158</option>
        <option value="weekly">\uC8FC\uAC04 \uBBF8\uC158</option>
      </select>
      <button type="submit" class="btn w-full bg-gradient-to-r from-orange-500 to-rose-500 text-white font-extrabold py-3.5 rounded-2xl">\uCD94\uAC00</button>
    </form>
  `),a("#missionForm").onsubmit=async e=>{e.preventDefault();let s=a("#mTitle").value.trim(),t=parseInt(a("#mGoal").value),o=a("#mKind").value;if(!s)return u("\uC81C\uBAA9\uC744 \uC785\uB825\uD574\uC918\uC694");await n.mutate("missions",{id:`${i.actorId}:${b()}:${o}`,user_id:i.actorId,kind:o,date:b(),title:s,goal:t,status:"pending",updated_at_ms:c()}),f(),u("\uBBF8\uC158 \uCD94\uAC00 \uC644\uB8CC!"),O()}}a("#sheetClose").onclick=f;_.onclick=f;window.openRecruitSheet=F;window.openMissionSheet=H;J();
